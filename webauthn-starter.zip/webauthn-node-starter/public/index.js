const { startRegistration, startAuthentication } = SimpleWebAuthnBrowser;

const msgTxt = document.querySelector(".message");
const loginBtn = document.querySelector(".login");
const regBtn = document.querySelector(".register");
const unameInput = document.querySelector(".username");

function displayMessage(msg) {
  msgTxt.innerHTML = msg;
}

async function myfetch(url, payload) {
  return await fetch(url, {
    method: "POST",
    body: JSON.stringify(payload),
    headers: { "Content-Type": "application/json" },
  }).then((res) => res.json());
}
